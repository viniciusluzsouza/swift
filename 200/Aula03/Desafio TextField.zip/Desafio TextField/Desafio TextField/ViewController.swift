//
//  ViewController.swift
//  Desafio TextField
//
//  Created by Vinicius Luz Souza on 17/01/2018.
//  Copyright © 2018 Vinicius Luz Souza. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtfieldEscreve: UITextField!
    @IBOutlet weak var txtfieldMostra: UITextField!
    @IBOutlet weak var myLB: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.txtfieldEscreve.delegate = self
        self.myLB.backgroundColor = UIColor.yellow
        self.myLB.text = ""
        self.txtfieldEscreve.placeholder = "Digite seu nome aqui."
        self.txtfieldMostra.isUserInteractionEnabled = false
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let nombre = self.txtfieldEscreve.text
        self.txtfieldMostra.text = nombre
        self.myLB.text = "Parabéns \(nombre!)! Desafio Concluído!"
        return true
    }

}

